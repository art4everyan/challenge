//Write a function sumAndProduct(_:) that takes two positive integers, a sum and a product, and returns the smallest two positive integers x and y, where x + y == sum, and x * y == product.
//Return x and y in an array with the smaller number first in the format [x, y]
//If a solution cannot be found, return the empty array

func sumAndProduct(integer1: Int, integer2: Int)  {
    for x in 1...integer1 {
        var array: [Int] = []
        var y = integer1 - x
        if x * y == integer2 {
            array.append(contentsOf: [x,y])
            print(array)
        } else {
            array = []
        }
    }
}
sumAndProduct(integer1: 6, integer2: 9)

